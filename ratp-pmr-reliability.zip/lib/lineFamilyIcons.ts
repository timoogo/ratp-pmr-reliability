export const lineFamilyIcons: Record<"metro" | "rer" | "tramway", string> = {
    metro: "/picto/metros/L_M.png",
    rer: "/picto/rers/rer_a.png",
    tramway: "/picto/tramway/T.png",
  };
  