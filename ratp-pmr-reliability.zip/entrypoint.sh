# Étape 1 : Base Node.js
FROM node:20-alpine

# Étape 2 : Définir le répertoire de travail
WORKDIR /app

# Étape 3 : Installer les dépendances système nécessaires (inutile : curl → retiré)
RUN apk add --no-cache postgresql-client

# Étape 4 : Copier le code source
COPY . .

# Étape 5 : Installer les dépendances
RUN if [ "$NODE_ENV" = "development" ]; then \
        npm install; \
    else \
        npm ci --omit=dev; \
    fi

# Étape 6 : Générer Prisma Client
RUN npx prisma generate

# Étape 7 : Compiler le seed uniquement
RUN npm run build:seed

# (Optionnel) Étape 8 : Compiler l'app principale si tu en as une
RUN npm run build

# Étape 9 : Rendre le script exécutable si tu en as un
RUN chmod +x /app/entrypoint.sh

# Étape 10 : Point d’entrée
CMD ["npm", "start"]
