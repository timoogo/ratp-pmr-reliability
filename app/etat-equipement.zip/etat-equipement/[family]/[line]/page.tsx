import { notFound } from "next/navigation";
import { ContentCardWrapper } from "@/components/ContentCardWrapper";
import { StationStepper } from "@/components/ui/StationStepper";
import { mockStations } from "@/mock/stations";

type PageProps = {
  params: {
    family: string;
    code: string;
    name: string;
    status: "ok" | "warning" | "current";
  };
};

export default function LineStatusPage({ params }: PageProps) {
  const { family, code } = params;

  if (!family || !code) return notFound();

  return (
    <div className="p-4 flex flex-col gap-4 bg-gray-200 min-h-screen">
      <h1 className="text-2xl font-bold">
        État des ascenseurs du {family.toUpperCase()} {code.toUpperCase()}
      </h1>

      <ContentCardWrapper>
        <p className="text-muted-foreground mb-2">
          Retrouvez en direct l’état des ascenseurs par station.
        </p>
        <StationStepper stations={mockStations} />
        
      </ContentCardWrapper>
    </div>
  );
}
